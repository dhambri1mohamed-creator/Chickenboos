// Données du menu
const menuItems = [
    {
        id: 1,
        name: "Poulet Rôti",
        description: "Poulet rôti avec herbes de Provence et légumes de saison",
        price: 15.90,
        category: "plats",
        image: "https://via.placeholder.com/300x180?text=Poulet+Rôti"
    },
    {
        id: 2,
        name: "Salade César",
        description: "Salade fraîche avec poulet grillé et sauce césar maison",
        price: 12.50,
        category: "entrees",
        image: "https://via.placeholder.com/300x180?text=Salade+César"
    },
    {
        id: 3,
        name: "Steak Frites",
        description: "Steak de bœuf avec frites maison et sauce au choix",
        price: 18.90,
        category: "plats",
        image: "https://via.placeholder.com/300x180?text=Steak+Frites"
    },
    {
        id: 4,
        name: "Tiramisu",
        description: "Dessert italien classique au café et mascarpone",
        price: 6.50,
        category: "desserts",
        image: "https://via.placeholder.com/300x180?text=Tiramisu"
    },
    {
        id: 5,
        name: "Pizza Margherita",
        description: "Pizza traditionnelle avec tomate, mozzarella et basilic",
        price: 13.90,
        category: "plats",
        image: "https://via.placeholder.com/300x180?text=Pizza+Margherita"
    },
    {
        id: 6,
        name: "Soda",
        description: "Boisson gazeuse au choix: Coca, Fanta, Sprite",
        price: 3.50,
        category: "boissons",
        image: "https://via.placeholder.com/300x180?text=Soda"
    }
];
// Panier
let cart = [];
let currentLocation = "";
// Éléments DOM
const menuGrid = document.getElementById('menuGrid');
const cartIcon = document.getElementById('cartIcon');
const cartPanel = document.getElementById('cartPanel');
const closeCart = document.getElementById('closeCart');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');
const cartCount = document.getElementById('cartCount');
const checkoutBtn = document.getElementById('checkoutBtn');
const categoryBtns = document.querySelectorAll('.category-btn');
const locationInput = document.getElementById('locationInput');
const locationBtn = document.getElementById('locationBtn');
const locationMap = document.getElementById('locationMap');
// Afficher les éléments du menu
function displayMenuItems(category = 'all') {
    menuGrid.innerHTML = '';
    
    const filteredItems = category === 'all' 
        ? menuItems 
        : menuItems.filter(item => item.category === category);
    
    filteredItems.forEach(item => {
        const menuItem = document.createElement('div');
        menuItem.className = 'menu-item';
        menuItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="item-image">
            <div class="item-details">
                <div class="item-name">${item.name}</div>
                <div class="item-description">${item.description}</div>
                <div class="item-price">${item.price.toFixed(2)} €</div>
                <button class="add-to-cart" data-id="${item.id}">Ajouter au panier</button>
            </div>
        `;
        menuGrid.appendChild(menuItem);
    });
    
    // Ajouter les écouteurs d'événements pour les boutons "Ajouter au panier"
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (e) => {
            const itemId = parseInt(e.target.getAttribute('data-id'));
            addToCart(itemId);
        });
    });
}
// Ajouter un article au panier
function addToCart(itemId) {
    const item = menuItems.find(menuItem => menuItem.id === itemId);
    const existingItem = cart.find(cartItem => cartItem.id === itemId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...item,
            quantity: 1
        });
    }
    
    updateCart();
    showNotification(`${item.name} ajouté au panier`);
}
// Mettre à jour le panier
function updateCart() {
    cartItems.innerHTML = '';
    let total = 0;
    let count = 0;
    
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${item.price.toFixed(2)} €</div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn minus" data-id="${item.id}">-</button>
                <span>${item.quantity}</span>
                <button class="quantity-btn plus" data-id="${item.id}">+</button>
            </div>
        `;
        cartItems.appendChild(cartItem);
        
        total += item.price * item.quantity;
        count += item.quantity;
    });
    
    cartTotal.textContent = `${total.toFixed(2)} €`;
    cartCount.textContent = count;
    
    // Ajouter les écouteurs d'événements pour les boutons de quantité
    document.querySelectorAll('.quantity-btn.minus').forEach(button => {
        button.addEventListener('click', (e) => {
            const itemId = parseInt(e.target.getAttribute('data-id'));
            decreaseQuantity(itemId);
        });
    });
    
    document.querySelectorAll('.quantity-btn.plus').forEach(button => {
        button.addEventListener('click', (e) => {
            const itemId = parseInt(e.target.getAttribute('data-id'));
            increaseQuantity(itemId);
        });
    });
}
// Augmenter la quantité
function increaseQuantity(itemId) {
    const item = cart.find(cartItem => cartItem.id === itemId);
    if (item) {
        item.quantity += 1;
        updateCart();
    }
}
// Diminuer la quantité
function decreaseQuantity(itemId) {
    const itemIndex = cart.findIndex(cartItem => cartItem.id === itemId);
    if (itemIndex !== -1) {
        if (cart[itemIndex].quantity > 1) {
            cart[itemIndex].quantity -= 1;
        } else {
            cart.splice(itemIndex, 1);
        }
        updateCart();
    }
}
// Afficher une notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background-color: var(--success);
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        z-index: 1000;
        transition: opacity 0.3s;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 2000);
}
// Filtrer par catégorie
categoryBtns.forEach(button => {
    button.addEventListener('click', () => {
        categoryBtns.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        const category = button.getAttribute('data-category');
        displayMenuItems(category);
    });
});
// Confirmer l'emplacement
locationBtn.addEventListener('click', () => {
    const address = locationInput.value.trim();
    if (address) {
        currentLocation = address;
        locationMap.textContent = `Emplacement confirmé: ${address}`;
        locationMap.style.backgroundColor = '#d4edda';
        locationMap.style.color = '#155724';
        showNotification('Emplacement enregistré avec succès');
    } else {
        showNotification('Veuillez entrer une adresse');
    }
});
// Commander
checkoutBtn.addEventListener('click', () => {
    if (cart.length === 0) {
        showNotification('Votre panier est vide');
        return;
    }
    
    if (!currentLocation) {
        showNotification('Veuillez confirmer votre emplacement');
        return;
    }
    
    // Simuler l'envoi de la commande
    const orderId = Math.floor(Math.random() * 10000);
    showNotification(`Commande #${orderId} passée avec succès!`);
    
    // Réinitialiser le panier
    cart = [];
    updateCart();
    cartPanel.classList.remove('open');
});
// Ouvrir/fermer le panier
cartIcon.addEventListener('click', () => {
    cartPanel.classList.add('open');
});
closeCart.addEventListener('click', () => {
    cartPanel.classList.remove('open');
});
// Initialiser l'application
displayMenuItems();